library(TTR)
library(DMwR)
library(dplyr)
library(zoo)
library(data.table)
library(e1071)
library(plyr)
library(OneR)
library(DMwR)
library(Matrix)
library(xgboost)
library(readr)
library(stringr)
library(caret)
library(car)
library(qdapTools)
library(MASS)
train_data = read.csv("train_data_model_1.csv")
test_data = read.csv("test_data_model.csv")

train_data[,c("Sensor1","Sensor2","Sensor3","Sensor4")] = log10(train_data[,c("Sensor1","Sensor2","Sensor3","Sensor4")])

test_data[,c("Sensor1","Sensor2","Sensor3","Sensor4")] = log10(test_data[,c("Sensor1","Sensor2","Sensor3","Sensor4")])

train_data = subset(train_data,select = -c(X,Unnamed..0,MachineID))
test_data = subset(test_data,select = -c(X,MachineID))

std_model <- preProcess(train_data[, !names(train_data) %in% c("ActionPoint","MachineModel")], method = c("center", "scale"))

train_data[, !names(train_data) %in% c("ActionPoint","MachineModel")] <- predict(object = std_model, newdata = train_data[, !names(train_data) %in% c("ActionPoint","MachineModel")])

test_data[, !names(test_data) %in% c("ActionPoint","MachineModel")] <- predict(object = std_model, newdata = test_data[, !names(test_data) %in% c("ActionPoint","MachineModel")])

head(train_data)

train_data$ActionPoint = as.numeric(as.factor(train_data$ActionPoint))

head(train_data)

train_rows <- sample(x = 1:nrow(train_data), size = 0.7*nrow(train_data))

train <- data.frame(train_data[train_rows, ])

test <- data.frame(train_data[-train_rows, ])

str(train)
str(test)

model_basic <- glm(formula = ActionPoint~. , data = train)
unique(train$ActionPoint)
unique(test$ActionPoint)
preds_model <- predict(model_basic, test[, !(names(test) %in% c("ActionPoint"))])
regr.eval(test$ActionPoint, preds_model)

count(preds_model)
a = table(preds_model,test$ActionPoint)
class(pred)
confusionMatrix(a, mode = "prec_recall")

summary(model_basic)

model_aic <- stepAIC(model_basic, direction = "both")

par(mfrow = c(2,2))

plot(model_aic)
vif(model_aic)

train$ActionPoint


preds_model <- predict(model_aic, test[, !(names(test) %in% c("ActionPoint"))])
regr.eval(test$ActionPoint, preds_model)

count(preds_model)
a = table(preds_model,test$ActionPoint)

vif(model_aic)

model_rf  <- train(ActionPoint~., tuneLength = 3, data = train_data, method = 
                     "rf", importance = TRUE,
                   trControl = trainControl(method = "cv",
                                            number = 5,
                                            savePredictions = "final",
                                            classProbs = T))


model_rf$pred

model_rf$pred[order(model_rf$pred$rowIndex),2]

confusionMatrix(model_rf$pred[order(model_rf$pred$rowIndex),2], train_data$ActionPoint,mode = "prec_recall")

#XGBOOST
train_data$ActionPoint = as.factor(train_data$ActionPoint)
new_dat = SMOTE(ActionPoint~., train_data, perc.over = 100,perc.under = 100)
train_rows <- sample(x = 1:nrow(train_data), size = 0.7*nrow(train_data))
train <- data.frame(train_data[train_rows, ])
test <- data.frame(train_data[-train_rows, ])

str(train)
str(test)

table(train$ActionPoint)


str(new_dat)
table(new_dat$ActionPoint)

new_dat$ActionPoint = as.numeric(as.factor(new_dat$ActionPoint))
test$ActionPoint=as.numeric(as.factor(test$ActionPoint))

train_matrix <- xgb.DMatrix(data = as.matrix(new_dat[, !(names(new_dat) %in% "ActionPoint")]), label = as.matrix(new_dat[, names(new_dat) %in% "ActionPoint"]))

str(train_matrix)

test_matrix <- xgb.DMatrix(data = as.matrix(test[, !(names(test) %in% "ActionPoint")]),label = as.matrix(test[, "ActionPoint"]))

str(test_matrix)

xgb_model_basic <- xgboost(data = train_matrix, max.depth = 6, eta = 0.1, nthread = 2, nround = 700, objective = "multi:softmax",num_class=4, verbose = 1, early_stopping_rounds = 100)

summary(xgb_model_basic)

basic_preds <- predict(xgb_model_basic, test_matrix)
a = table(basic_preds,test$ActionPoint)
class(basic_preds)
confusionMatrix(a, mode = "prec_recall")

new_dat = SMOTE(ActionPoint~., train_data, perc.over = 1000,perc.under = 500)
str(new_dat)
count(new_dat$ActionPoint)

new_dat$ActionPoint = as.numeric(as.factor(new_dat$ActionPoint))
train_fin_matrix <- xgb.DMatrix(data = as.matrix(new_dat[, !(names(new_dat) %in% "ActionPoint")]), label = as.matrix(new_dat[, names(new_dat) %in% "ActionPoint"]))

test_fin_matrix <- xgb.DMatrix(data = as.matrix(test_data,label = as.matrix(test_data[, "ActionPoint"])))

xgb_model_basic <- xgboost(data = train_fin_matrix, max.depth = 6, eta = 0.1, nthread = 2, nround = 700, objective = "multi:softmax",num_class=4, verbose = 1, early_stopping_rounds = 100)

summary(xgb_model_basic)
basic_preds <- predict(xgb_model_basic, test_fin_matrix)


count(basic_preds)

test_data = read.csv("test_data_model.csv")
test_data$ActionPoint = basic_preds
test_data$ActionPoint <- mapvalues(test_data$ActionPoint,
                                   from = c(1,2,3),
                                   to = c("ComponentRepair", "ComponentReplacement", "NoIssue"))

submissiondf = subset(test_data,select = c(MachineID,ActionPoint))
write.csv(submissiondf,"predictions_xg_ss.csv")
