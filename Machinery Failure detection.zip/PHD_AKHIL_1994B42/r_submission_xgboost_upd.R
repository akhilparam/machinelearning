library(e1071)
library(plyr)
library(OneR)
library(DMwR)
library(Matrix)
library(xgboost)
library(readr)
library(stringr)
library(caret)
library(car)
library(qdapTools)

set.seed(123)
train_data = read.csv("train_data_model.csv")
test_data = read.csv("test_data_model.csv")
str(train_data)
x = mtabulate(train_data$MachineModel)
y = mtabulate(test_data$MachineModel)

train_data[c("Model1","Model2","Model3","Model4")] = data.frame(x)
test_data[c("Model1","Model2","Model3","Model4")] = data.frame(y)

train_data$ServicePeriod = bin(train_data$ServicePeriod, nbins = 3, labels = c("short", "average", "long"))
test_data$ServicePeriod = bin(test_data$ServicePeriod, nbins = 3, labels = c("short", "average", "long"))
x = mtabulate(train_data$ServicePeriod)
y = mtabulate(test_data$ServicePeriod)
train_data[c("short_life","average_life","long_life")] = data.frame(x)
test_data[c("short_life","average_life","long_life")] = data.frame(y)

train_data = subset(train_data,select = -c(X,MachineID,MachineModel,ServicePeriod))
test_data = subset(test_data,select = -c(X,MachineID,MachineModel,ServicePeriod))
head(train_data)

train_rows <- sample(x = 1:nrow(train_data), size = 0.7*nrow(train_data))
train <- data.frame(train_data[train_rows, ])
test <- data.frame(train_data[-train_rows, ])

str(train)
str(test)

table(train$ActionPoint)

new_dat = SMOTE(ActionPoint~., train, perc.over = 10000,perc.under = 50)
str(new_dat)
table(new_dat$ActionPoint)

new_dat$ActionPoint = as.numeric(as.factor(new_dat$ActionPoint))
test$ActionPoint=as.numeric(as.factor(test$ActionPoint))

train_matrix <- xgb.DMatrix(data = as.matrix(new_dat[, !(names(new_dat) %in% "ActionPoint")]), label = as.matrix(new_dat[, names(new_dat) %in% "ActionPoint"]))

str(train_matrix)

test_matrix <- xgb.DMatrix(data = as.matrix(test[, !(names(test) %in% "ActionPoint")]),label = as.matrix(test[, "ActionPoint"]))

str(test_matrix)

xgb_model_basic <- xgboost(data = train_matrix, max.depth = 6, eta = 0.1, nthread = 2, nround = 700, objective = "multi:softmax",num_class=4, verbose = 1, early_stopping_rounds = 100)

summary(xgb_model_basic)

basic_preds <- predict(xgb_model_basic, test_matrix)
a = table(basic_preds,test$ActionPoint)
class(basic_preds)
confusionMatrix(a, mode = "prec_recall")

new_dat = SMOTE(ActionPoint~., train_data, perc.over = 100000,perc.under = 500)
str(new_dat)
count(new_dat$ActionPoint)

new_dat$ActionPoint = as.numeric(as.factor(new_dat$ActionPoint))
train_fin_matrix <- xgb.DMatrix(data = as.matrix(new_dat[, !(names(new_dat) %in% "ActionPoint")]), label = as.matrix(new_dat[, names(new_dat) %in% "ActionPoint"]))

test_fin_matrix <- xgb.DMatrix(data = as.matrix(test_data,label = as.matrix(test_data[, "ActionPoint"])))

xgb_model_basic <- xgboost(data = train_fin_matrix, max.depth = 6, eta = 0.1, nthread = 2, nround = 700, objective = "multi:softmax",num_class=4, verbose = 1, early_stopping_rounds = 100)

summary(xgb_model_basic)
basic_preds <- predict(xgb_model_basic, test_fin_matrix)

count(basic_preds)

test_data = read.csv("test_data_model.csv")
test_data$ActionPoint = basic_preds
test_data$ActionPoint <- mapvalues(test_data$ActionPoint,
                     from = c(1,2,3),
                     to = c("ComponentRepair", "ComponentReplacement", "NoIssue"))

submissiondf = subset(test_data,select = c(MachineID,ActionPoint))
write.csv(submissiondf,"predictions_xgb_ud.csv")