#New High score using subset selection columns and oversampling the data

library(e1071)
library(plyr)
library(OneR)
library(DMwR)
library(Matrix)
library(xgboost)
library(readr)
library(stringr)
library(caret)
library(car)
library(qdapTools)
set.seed(123)


train_data = read.csv("train_data_model.csv")
head(train_data)
test_data = read.csv("test_data_model.csv")
str(train_data)
train_data = subset(train_data,select = c(Error1,Error2,Error3,Error4,Error5,ActionPoint))
test_data = subset(test_data,select = c(Error1,Error2,Error3,Error4,Error5))
head(train_data)

std_model <- preProcess(train_data[, !names(train_data) %in% c("ActionPoint","MachineModel")], method = c("center", "scale"))

train_data[, !names(train_data) %in% c("ActionPoint","MachineModel")] <- predict(object = std_model, newdata = train_data[, !names(train_data) %in% c("ActionPoint","MachineModel")])

test_data[, !names(test_data) %in% c("ActionPoint","MachineModel")] <- predict(object = std_model, newdata = test_data[, !names(test_data) %in% c("ActionPoint","MachineModel")])


train_rows <- sample(x = 1:nrow(train_data), size = 0.7*nrow(train_data))
train <- data.frame(train_data[train_rows, ])
test <- data.frame(train_data[-train_rows, ])

str(train)
str(test)

table(train$ActionPoint)

new_dat = SMOTE(ActionPoint~., train, perc.over = 10000,perc.under = 50)

str(new_dat)
table(new_dat$ActionPoint)

new_dat$ActionPoint = as.numeric(as.factor(new_dat$ActionPoint))
test$ActionPoint=as.numeric(as.factor(test$ActionPoint))

train_matrix <- xgb.DMatrix(data = as.matrix(new_dat[, !(names(new_dat) %in% "ActionPoint")]), label = as.matrix(new_dat[, names(new_dat) %in% "ActionPoint"]))

str(train_matrix)

test_matrix <- xgb.DMatrix(data = as.matrix(test[, !(names(test) %in% "ActionPoint")]),label = as.matrix(test[, "ActionPoint"]))

str(test_matrix)

xgb_model_basic <- xgboost(data = train_matrix, max.depth = 6, eta = 0.1, nthread = 2, nround = 700, objective = "multi:softmax",num_class=4, verbose = 1, early_stopping_rounds = 100)

summary(xgb_model_basic)

basic_preds <- predict(xgb_model_basic, test_matrix)
a = table(basic_preds,test$ActionPoint)
class(basic_preds)
confusionMatrix(a, mode = "prec_recall")

new_dat = SMOTE(ActionPoint~., train_data, perc.over = 10000,perc.under = 50)
str(new_dat)
count(new_dat$ActionPoint)

new_dat$ActionPoint = as.numeric(as.factor(new_dat$ActionPoint))
train_fin_matrix <- xgb.DMatrix(data = as.matrix(new_dat[, !(names(new_dat) %in% "ActionPoint")]), label = as.matrix(new_dat[, names(new_dat) %in% "ActionPoint"]))

test_fin_matrix <- xgb.DMatrix(data = as.matrix(test_data,label = as.matrix(test_data[, "ActionPoint"])))

xgb_model_basic <- xgboost(data = train_fin_matrix, max.depth = 6, eta = 0.1, nthread = 2, nround = 700, objective = "multi:softmax",num_class=4, verbose = 1, early_stopping_rounds = 100)

summary(xgb_model_basic)
basic_preds <- predict(xgb_model_basic, test_fin_matrix)


count(basic_preds)

test_data = read.csv("test_data_model.csv")
test_data$ActionPoint = basic_preds
test_data$ActionPoint <- mapvalues(test_data$ActionPoint,
                                   from = c(1,2,3),
                                   to = c("ComponentRepair", "ComponentReplacement", "NoIssue"))

submissiondf = subset(test_data,select = c(MachineID,ActionPoint))
write.csv(submissiondf,"predictions_xg_ss.csv")
