library(e1071)
library(plyr)
library(OneR)
library(DMwR)
library(Matrix)
library(xgboost)
library(readr)
library(stringr)
library(caret)
library(car)
library(qdapTools)



train_data = read.csv("train_data_model.csv")
test_data = read.csv("test_data_model.csv")
str(train_data)
str(test_data)
train_data = subset(train_data,select = -c(X,MachineID))
test_data = subset(test_data,select = -c(X,MachineID))
#train_data = subset(train_data,select = -c(X))
#factor(train_data$ActionPoint)

#train_data[,2:15] = round(train_data[,2:15])
#test_data[,2:14] = round(test_data[,2:14])
set.seed(456)
train_rows <- sample(x = 1:nrow(train_data), size = 0.7*nrow(train_data))

train <- data.frame(train_data[train_rows, ])

test <- data.frame(train_data[-train_rows, ])

str(train)
str(test)

table(train$ActionPoint)

#rm(train)
#train = SMOTE(ActionPoint~., train, perc.over = 100,perc.under = 800)
str(train)
str(test)
table(train$ActionPoint)

head(train)
train$ActionPoint = as.numeric(as.factor(train$ActionPoint))
test$ActionPoint=as.numeric(as.factor(test$ActionPoint))
#train$MachineID = as.numeric(as.factor(train$MachineID))
#test$MachineID=as.numeric(as.factor(test$MachineID))


std_model <- preProcess(train[, !names(train) %in% c("ActionPoint","MachineModel")], method = c("center", "scale"))

train[, !names(train) %in% c("ActionPoint","MachineModel")] <- predict(object = std_model, newdata = train[, !names(train) %in% c("ActionPoint","MachineModel")])

test[, !names(test) %in% c("ActionPoint","MachineModel")] <- predict(object = std_model, newdata = test[, !names(test) %in% c("ActionPoint","MachineModel")])


#train_data1 = subset(train_data,select=-c(ActionPoint,MachineID))
pred=knn(train,test,
         train$ActionPoint, 
         k = 3)

length(pred)

a = table(pred,test$ActionPoint)
class(pred)
confusionMatrix(a,mode = "prec_recall")


str(train_data)
str(test_data)
new_data = 
  pred_test = knn(train_data[2:16],test_data,
                  train_data$ActionPoint, 
                  k = 3)

count(pred_test)
test_data = read.csv("test_data_model.csv")
test_data = read.csv("test_data_model.csv")
test_data$ActionPoint = pred_test

submission_file = subset(test_data,select = c(MachineID,ActionPoint))

write.csv(submission_file,"predictions_knn.csv")