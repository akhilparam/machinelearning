setwd("C:/Users/THINKPAD/Desktop/PhD")
library(e1071)
library(plyr)
library(OneR)
library(DMwR)
library(Matrix)
library(xgboost)
library(readr)
library(stringr)
library(caret)
library(car)
library(qdapTools)

train_data = read.csv("train_data_model.csv")
str(train_data)
train_data = subset(train_data,select = -c(X,MachineID,Error5))
factor(train_data$ActionPoint)
train_data$ActionPoint = as.numeric(as.factor(train_data$ActionPoint))

train_rows <- sample(x = 1:nrow(train_data), size = 0.7*nrow(train_data))

train <- data.frame(train_data[train_rows, ])

test <- data.frame(train_data[-train_rows, ])

str(train)
str(test)

std_model <- preProcess(train[, !names(train) %in% c("ActionPoint","MachineModel")], method = c("center", "scale"))


# The predict() function is used to standardize any other unseen data

train[, !names(train) %in% c("ActionPoint","MachineModel")] <- predict(object = std_model, newdata = train[, !names(train_data) %in% c("ActionPoint","MachineModel")])

test[, !names(train) %in% c("ActionPoint","MachineModel")] <- predict(object = std_model, newdata = test[, !names(train) %in% c("ActionPoint","MachineModel")])

model_basic <- glm(formula = ActionPoint~. , data = train)
unique(train$ActionPoint)
unique(test$ActionPoint)
preds_model <- predict(model_basic, test[, !(names(test) %in% c("ActionPoint"))])
regr.eval(test$ActionPoint, preds_model)

count(preds_model)
a = table(preds_model,test$ActionPoint)
class(pred)
confusionMatrix(a, mode = "prec_recall")

summary(model_basic)

model_aic <- stepAIC(model_basic, direction = "both")

par(mfrow = c(2,2))

plot(model_aic)
#vif(model_aic)
train$ActionPoint


preds_model <- predict(model_aic, test[, !(names(test) %in% c("ActionPoint"))])
regr.eval(test$ActionPoint, preds_model)

count(preds_model)
a = table(preds_model,test$ActionPoint)
class(pred)
confusionMatrix(a, mode = "prec_recall")
cor()
vif(model_aic)
