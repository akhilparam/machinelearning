#nb
train_data = read.csv("train_data_model_1.csv")
test_data = read.csv("test_data_model.csv")

train_data = subset(train_data,select = -c(Unnamed..0,X))
test_data = subset(test_data,select = -c(X))

train_data[,c("Sensor1","Sensor2","Sensor3","Sensor4")] = log10(train_data[,c("Sensor1","Sensor2","Sensor3","Sensor4")])

test_data[,c("Sensor1","Sensor2","Sensor3","Sensor4")] = log10(test_data[,c("Sensor1","Sensor2","Sensor3","Sensor4")])

train_data = subset(train_data,select = -c(Sensor1,Sensor2,Sensor3,Sensor4))

 x = mtabulate(train_data$MachineModel)
 y = mtabulate(test_data$MachineModel)
 
train_data[c("Model1","Model2","Model3","Model4")] = data.frame(x)
test_data[c("Model1","Model2","Model3","Model4")] = data.frame(y)
train_data$ServicePeriod = bin(train_data$ServicePeriod, nbins = 5, labels = c("cat1", "cat2", "cat3","cat4","cat5"))
test_data$ServicePeriod = bin(test_data$ServicePeriod, nbins = 5, labels = c("cat1", "cat2", "cat3","cat4","cat5"))
x = mtabulate(train_data$ServicePeriod)
y = mtabulate(test_data$ServicePeriod)
train_data[c("cat1", "cat2", "cat3","cat4","cat5")] = data.frame(x)
test_data[c("cat1", "cat2", "cat3","cat4","cat5")] = data.frame(y)


smoted_data = SMOTE(ActionPoint~., train_data, perc.over = 18,perc.under = 875)
count(smoted_data$ActionPoint)

train_rows <- sample(x = 1:nrow(smoted_data), size = 0.7*nrow(smoted_data))
train <- data.frame(smoted_data[train_rows, ])
test <- data.frame(smoted_data[-train_rows, ])
str(train)
str(test)

nb_model <- naiveBayes(ActionPoint~.,data = train)
nb_model

nb_test_predict <- predict(nb_model,test)
cf = table(pred=nb_test_predict,test$ActionPoint)
confusionMatrix(cf,mode = 'prec_recall')


count(smoted_data$ActionPoint)
nb_model <- naiveBayes(ActionPoint~.,data = smoted_data)
nb_test_predict <- predict(nb_model,test_data)
count(nb_test_predict)

test_data = read.csv("test_data_model.csv")
test_data$ActionPoint = nb_test_predict

submissiondf = subset(test_data,select = c(MachineID,ActionPoint))
write.csv(submissiondf,"predictions_nb.csv")